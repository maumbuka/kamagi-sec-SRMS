from django.contrib import admin
from .models import  StudentClass

admin.site.register(StudentClass)
