from django.apps import AppConfig


class StudentClassesConfig(AppConfig):
    name = 'student_classes'
