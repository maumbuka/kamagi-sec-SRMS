from django.db import models
from django.urls import reverse
# Create your models here.


class StudentClass(models.Model):
    class_name = models.CharField(max_length=100, help_text='Eg- Form One, Form Two, Form Three, Form Four')
    class_name_in_numeric = models.IntegerField(help_text='Eg- 1,2,3,4')
    creation_date = models.DateTimeField(auto_now=False, auto_now_add=True)

    def get_absolute_url(self):
        return reverse('student_classes:class_list')

    def __str__(self):
        return self.class_name
