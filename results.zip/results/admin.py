from django.contrib import admin
from .models import DeclareResult

admin.site.register(DeclareResult)